@ECHO OFF
CHCP 950 >NUL
SETLOCAL EnableExtensions DisableDelayedExpansion
REM ===============================================================================
REM CJPsAddin �w�˵{�� v1.12
REM ===============================================================================
REM �\��G
REM   1. ���o�妸�ɦP��Ƨ��� CJPsAddin.xla�C
REM   2. �u���w�˨� D:\VBA�F���Ѯɧ�� C:\VBA�C
REM   3. �����D�ɦw�ˬ� CJPsAddin.xla�AExcel �ȫإߦ��ɮת� OPEN �Ұʳ]�w�C
REM   4. �������ª����ҡF�u���¦W�����ɦs�b�B Excel OPEN ���ޥ��¦W�ɡA�~�إ� !�ӤH�M�ݱ`�Υ���.xla �ۮe�ƥ��C
REM   5. �Y�J�� OPEN ���V���ɦW�A�����N�� OPEN ��a�E���� CJPsAddin.xla�A�קK����P�ɸ��J�C
REM   6. �ˬd Zone.Identifier ADS�F�u�� ZoneId=3/4 �~�Ѱ� MOTW�C
REM   7. �ֳt�s���u��C�G�s�ϥΪ̦۰ʥ[�J 3 �ӱ`�Υ\��F�¨ϥΪ̾E���� Add-in ���s�ޥΡC
REM   8. �N�w�˸�Ƨ��[�J Excel Trusted Location�A�� CJPsAddin �b���쥨�����ήɤ��i����C
REM   9. ���򤣦w�������� VBA �]�w�GVBAWarnings=1 �ɧאּ 2�F�ª����ҭY AccessVBOM=1 �h�אּ 0�C
REM  10. �ˬd�`�� Office / Excel Policy�A�ò��ͶE�_���i�C
REM
REM �]�p��h�G
REM   - ���мg���~ Policy�F�Y�����w���]�w�� Policy �޲z�A�u�O���Ӥ��ק�C
REM   - VBAWarnings �u�ѡu�ҥΩҦ������v(1) ���򬰡u���Ψóq���v(2)�A����e��L�J���]�w�C
REM   - AccessVBOM �u�b�������ª����ҥB�Ȭ� 1 �������A�Ψӭ״_�¦w�˻����d�U���]�w�C
REM   - CMD ����T�w�� CP950 + CRLF�A�èϥ� CHCP 950�F�o�O�ثe���í�w���c�餤�����ҲզX�C
REM   - VBS helper ��������� ASCII�F������|�u�z�L Arguments �ǤJ�C
REM   - ���ק� AddInLoadTimes�BResiliency�F�u�B�z�w�˯u���ݭn�� Options\OPEN �]�w�C
REM   - �¦W�ۮe�ƥ��u�ѬJ������ï�M���¸��|�A���@�� Excel �۰ʸ��J�ӷ��C
REM
REM �ק�����G
REM 2026.10.12 v1.12
REM   - ���� NAS �ƴ��G�u���o�妸�ɦP��Ƨ��� CJPsAddin.xla (�w�˵{���i���}�A���t���q�������|)�C
REM   - �ק������^�̤���ѷs���±ƦC (v1.11 �쥻�Ʀb v1.05 ����)�C
REM 2026.10.08 v1.11
REM   - �ӷ��P�D�ɥت��a�ۦP�ɲ��L�D�ɸѰ���Ū�νƻs�A����y�{�ӱ`����C
REM 2026.10.07 v1.10
REM   - �ץ� QAT helper ���ͪťզ�ɨϥ� ECHO �y�� VBScript �Q�g�J ECHO ���A��r�B�ɭP�sĶ���ѡC
REM   - QAT helper ���ťդ��j��Τ@��� ECHO.�F���Ѯ� Debug VBS �אּ�����O�d�� Installer �P�ؿ��C
REM   - QAT XML�B���s�B�ϥܡBOPEN�BTrusted Location �P�w���]�w�y�{���ܡC
REM 2026.10.07 v1.08
REM   - �ץ� QAT XML �j�M���A�̿�T�w Office CustomUI namespace�F��H DOM �`�I�v�@���� sharedControls / button�C
REM   - ��l�w�ˡBOPEN�BTrusted Location �P�w���]�w�y�{���ܡC
REM 2026.10.07 v1.05
REM   - �ץ� QAT helper �ϥ� VBScript �O�d�r Shared �@���ܼƦW�١A�y���sĶ���~�C
REM   - QAT helper �ܼƧאּ sharedControls�F��L�w�ˡBOPEN�BTrusted Location �P�w���]�w�y�{���ܡC
REM   - QAT helper ���ѮɫO�d Debug VBS�A��K�����w�������~�C
REM 2026.10.07 v1.04
REM   - �s�ϥΪ̦۰ʦb Excel �ֳt�s���u��C�e 3 �Ӧ�m�[�J�G�z��j��_�������B�z��j��_�ҽk���BProShowAllData�C
REM   - �ª��ϥΪ̥u�E�� Excel.officeUI �������V�� Add-in �� QAT ���s�A����ʨ�L�ۭq�C
REM   - �ק� Excel.officeUI �e�إߤ@���ʳƥ� Excel.officeUI.CJPsAddinBackup�FXML ���ҥ��Ѯɤ��мg���ɡC
REM   - Trusted Location �� Description �אּ�T�w�Ƶ��uCJPsAddin �w�˦�m�]�� Installer �إߡ^�v�F�J���ۦP���|�]�P�B��s�Ƶ��C
REM   - �ץ� Trusted Location helper �������m Legacy / Security ���A�����޿�C
REM 2026.10.06 v1.03
REM   - �ª����ҧP�w�אּ�G�¦W�����ɦs�b AND Excel OPEN ���ޥ��¦W�A��̬Ҧ��ߤ~�i���ª��E���C
REM   - �Ȧ����ɩζȦ��ݯd OPEN �ɤ��إ߬ۮe�ƥ��F�E�_���i���O�d�ӧO�������G�C
REM 2026.10.06 v1.02
REM   - �s�ϥΪ̥u�w�� CJPsAddin.xla�F�������ª�����ɤ~�إ��¦W�ۮe�ƥ��C
REM   - �w�˸�Ƨ��אּ���n Trusted Location�A���A�ĲĤG������ fallback�C
REM   - VBAWarnings=1 �ɦ۰ʦ��� 2�F�ª����� AccessVBOM=1 �ɦ۰ʧאּ 0�C
REM   - ���~ Policy �u���A�������мg���޲z���w���]�w�C
REM 2026.10.05 v1.00
REM   - �����w�˦W�٧אּ CJPsAddin.xla�C
REM   - �إ� !�ӤH�M�ݱ`�Υ���.xla �¦W�ۮe�ƥ��A�����إ� OPEN �ޥΡC
REM   - �s�W�� OPEN ���|�E���G�J���¦W OPEN ��������V CJPsAddin.xla�C
REM   - �u�Τw������\�� OPEN ���[�ơBMOTW�BPolicy �P Diagnostic �y�{�C
REM ===============================================================================

REM ==============================
REM �����ܼ�
REM ==============================
SET "SRC_FILE=CJPsAddin.xla"
SET "DEST_FILE=CJPsAddin.xla"
SET "LEGACY_FILE=!�ӤH�M�ݱ`�Υ���.xla"

SET "DEST_DIR_1=D:\VBA"
SET "DEST_DIR_2=C:\VBA"

SET "SRC=%~dp0%SRC_FILE%"
SET "DEST_DIR="
SET "DEST="
SET "LEGACY_DEST="
SET "DIAG_FILE=%~dp0InstallDiagnostic.txt"
SET "LOG_VBS=%TEMP%\ExcelAddinLog_%RANDOM%_%RANDOM%.vbs"
SET "VBS_FILE=%TEMP%\ExcelAddinInstall_%RANDOM%_%RANDOM%.vbs"
SET "ADDIN_RESULT=%TEMP%\ExcelAddinResult_%RANDOM%_%RANDOM%.txt"
SET "VBS_LOG=%TEMP%\ExcelAddinVbs_%RANDOM%_%RANDOM%.log"
SET "EXCEL_VERSION="
SET "POLICY_FOUND=0"
SET "MOTW_FOUND=0"
SET "ZONE_ID="
SET "REGISTER_OK=0"
SET "OPEN_VALUE_NAME="
SET "REGISTER_ACTION="
SET "TRUST_ACTION="
SET "TRUST_LOCATION_NAME="
SET "TRUST_OK=0"
SET "LEGACY_DETECTED=0"
SET "LEGACY_FILE_FOUND=0"
SET "LEGACY_OPEN_FOUND=0"
SET "SECURITY_OK=0"
SET "VBA_WARNINGS_ACTION="
SET "ACCESSVBOM_ACTION="
SET "QAT_FILE=%LOCALAPPDATA%\Microsoft\Office\Excel.officeUI"
SET "QAT_BACKUP=%LOCALAPPDATA%\Microsoft\Office\Excel.officeUI.CJPsAddinBackup"
SET "QAT_OK=0"
SET "QAT_ACTION="
SET "QAT_DEBUG=%~dp0QAT_Debug_v1.12.vbs"
SET "TRUST_DESCRIPTION=CJPsAddin �w�˦�m�]�Ѱ��Τ@�� VBA �����ɸ��J�W�q���^"



REM ==============================
REM �w�˫e��T�P�ϥΪ̽T�{
REM ==============================
CLS
ECHO.
ECHO ==========================================
ECHO  CJPsAddin �w�˵{�� v1.12
ECHO ==========================================
ECHO.

IF NOT EXIST "%SRC%" (
    ECHO �䤣��ӷ��W�q���G
    ECHO %SRC%
    GOTO :ERROR_NO_LOG
)

ECHO �Y�N����H�U�ʧ@�G
ECHO.
ECHO  - �ӷ��W�q���G%SRC_FILE%
ECHO  - �����w�˦W�١G%DEST_FILE%
ECHO  - �ª��ϥΪ̤~�|�إ߬ۮe�ƥ��G%LEGACY_FILE%
ECHO  - �ӷ��ɡG%SRC%
ECHO  - �u���w�˦ܡG%DEST_DIR_1%
ECHO  - �ƥΦw�˦ܡG%DEST_DIR_2%
ECHO  - �Y�w���ɮ׫h�л\�í��s�]�w��Ū
ECHO  - �ˬd Zone.Identifier / MOTW
ECHO  - Excel �ȫإ� %DEST_FILE% �����[�ƱҰʳ]�w
ECHO  - �Y�������¦W OPEN �]�w�A�N�۰ʾE���ܷs�W��
ECHO  - �ˬd�`�� Excel / Office Policy
ECHO  - �s�ϥΪ̦۰ʥ[�J 3 �ӱ`�� QAT ���s�F�¨ϥΪ̾E���«��s�ޥ�
ECHO  - �N�w�˸�Ƨ��[�J Excel �H����m
ECHO  - �Y�ثe���u�ҥΩҦ� VBA �����v�A�אּ�u���� VBA �����]�ƥ��q���^�v
ECHO.
ECHO  �ª��ϥΪ̤~�|�إ��¦W�ۮe�ƥ��F�Ӱƥ����|�إ� Excel OPEN �ޥΡC
ECHO  �w�˵{�����|�мg���~ Policy�A�]���|��e�J���������w���]�w�C
ECHO ==========================================
ECHO.

CHOICE /C YN /M "�нT�{�O�_�~��H�]Y=�O, N=�_�^"
IF ERRORLEVEL 2 GOTO :CANCEL

REM ==============================
REM �ˬd Excel �O�_���b����
REM �קK�W�q���Q��w�A�� COM ���U�P�J�� Excel Process �V�b�@�_
REM ==============================
:CHECK_EXCEL_RUNNING
TASKLIST /FI "IMAGENAME eq EXCEL.EXE" /NH 2>NUL | FIND /I "EXCEL.EXE" >NUL
IF ERRORLEVEL 1 GOTO :EXCEL_CLOSED
ECHO.
ECHO ==========================================
ECHO  ������ Microsoft Excel ���b����C
ECHO ==========================================
ECHO.
ECHO �Х��x�s�u�@�������Ҧ� Excel �����A�A���s�ˬd�C
ECHO Installer ���|�j������ Excel�A�H�קK���x�s��ƿ򥢡C
ECHO.
CHOICE /C RC /M "R=���s�ˬd, C=����"
IF ERRORLEVEL 2 GOTO :CANCEL
GOTO :CHECK_EXCEL_RUNNING

:EXCEL_CLOSED


REM ==============================
REM �إ߶E�_���i Writer
REM VBS ��������� ASCII�F�z�L ADODB.Stream ���� UTF-8 �L BOM �E�_���i
REM �קK CMD redirect �V�Τ��P�{����X�ɳy���s�X�V��
REM ==============================
CALL :CREATE_LOGGER
IF ERRORLEVEL 1 (
    ECHO [ERROR] Could not create diagnostic writer.
    GOTO :ERROR_NO_LOG
)
DEL /Q "%DIAG_FILE%" 2>NUL
CALL :LOG "=============================================================================="
CALL :LOG "Excel Add-in Installation Diagnostic"
CALL :LOG "=============================================================================="
CALL :LOG "Date/Time      : %DATE% %TIME%"
CALL :LOG "Computer       : %COMPUTERNAME%"
CALL :LOG "User           : %USERNAME%"
CALL :LOG "Source         : %SRC%"
CALL :LOG "Main Target    : %DEST_FILE%"
CALL :LOG "Legacy Target  : %LEGACY_FILE%"
CALL :LOG "Legacy Mode    : pending detection"
CALL :LOG "Installer      : CJPsAddin Installer v1.12 / CP950 / CRLF / OPEN persistence / QAT migration"
CALL :LOG ""


REM ==============================
REM 1. Excel COM �ˬd
REM �T�{ Excel �i�� COM �إߡA�è��o Version
REM ==============================
ECHO.
ECHO [1/9] �ˬd Microsoft Excel...
CALL :LOG "[STAGE] 1 - Excel COM check"
CALL :CHECK_EXCEL_COM
IF ERRORLEVEL 1 GOTO :ERROR
ECHO [OK] �w������ Microsoft Excel %EXCEL_VERSION%�C
CALL :LOG "[OK] Excel Version : %EXCEL_VERSION%"


REM ==============================
REM 2. �ǳƥت���Ƨ�
REM �u�� D:\VBA�A���Ѥ~��� C:\VBA
REM ==============================
ECHO.
ECHO [2/9] �ǳƦw�˦�m...
CALL :LOG "[STAGE] 2 - Destination"

SET "DEST_DIR=%DEST_DIR_1%"
IF NOT EXIST "%DEST_DIR%" MKDIR "%DEST_DIR%" 2>NUL
IF EXIST "%DEST_DIR%" GOTO :DEST_READY

SET "DEST_DIR=%DEST_DIR_2%"
IF NOT EXIST "%DEST_DIR%" MKDIR "%DEST_DIR%" 2>NUL
IF NOT EXIST "%DEST_DIR%" (
    ECHO [ERROR] Could not create %DEST_DIR_1% or %DEST_DIR_2%
    CALL :LOG "[ERROR] Cannot create destination directory."
    GOTO :ERROR
)

:DEST_READY
SET "DEST=%DEST_DIR%\%DEST_FILE%"
SET "LEGACY_DEST=%DEST_DIR%\%LEGACY_FILE%"
ECHO [OK] �w�˦�m�G%DEST_DIR%
CALL :LOG "[OK] Main Target    : %DEST%"
CALL :LOG "[OK] Legacy Target  : %LEGACY_DEST%"

REM ==============================
REM �����ª�����
REM �¦W�ɮצs�b�B OPEN �Ȥ����V�¦W���|�A��̬Ҧ��ߤ~�����ª��ϥΪ̡C
REM ==============================
CALL :DETECT_LEGACY
IF ERRORLEVEL 1 GOTO :ERROR
IF "%LEGACY_DETECTED%"=="1" (
    ECHO [INFO] �������ª����ҡA�N�إ��¦W�ۮe�ƥ��öi��E���C
    CALL :LOG "[INFO] Legacy environment : Detected"
) ELSE (
    ECHO [INFO] ���������ª����ҡA�����u�w�� %DEST_FILE%�C
    CALL :LOG "[INFO] Legacy environment : Not detected"
)
CALL :LOG "[INFO] Legacy file        : %LEGACY_FILE_FOUND%"
CALL :LOG "[INFO] Legacy OPEN        : %LEGACY_OPEN_FOUND%"
IF "%LEGACY_FILE_FOUND%"=="0" IF "%LEGACY_OPEN_FOUND%"=="1" CALL :LOG "[WARNING] Legacy OPEN registration exists, but legacy file was not found. Legacy migration will not run."
IF "%LEGACY_FILE_FOUND%"=="1" IF "%LEGACY_OPEN_FOUND%"=="0" CALL :LOG "[INFO] Legacy file exists without matching OPEN registration. Legacy migration will not run."


REM ==============================
REM �Ѱ��J���D�ɻP�¦W�ۮe�ƥ�����Ū�ݩ�
REM �u���ɮפw�s�b�ɤ~�B�z
REM ==============================
REM �ӷ��P�D�ɬۦP�ɤ��Ѱ��D�ɰ�Ū�A�]���ƻs�D�ɡC
FOR %%F IN ("%SRC%") DO SET "SRC_FULL=%%~fF"
FOR %%F IN ("%DEST%") DO SET "DEST_FULL=%%~fF"
SET "SAME_SOURCE_DEST=0"
IF /I "%SRC_FULL%"=="%DEST_FULL%" SET "SAME_SOURCE_DEST=1"
IF "%SAME_SOURCE_DEST%"=="1" (
    ECHO [INFO] �ӷ��P�ت��a�ۦP�A���L�D�ɽƻs�C
    CALL :LOG "[INFO] Source equals destination; main copy skipped."
)
IF "%SAME_SOURCE_DEST%"=="0" IF EXIST "%DEST%" (
    ATTRIB -R "%DEST%" 2>NUL
    IF ERRORLEVEL 1 (
        ECHO [ERROR] �L�k�Ѱ��J���D�ɪ���Ū�ݩʡG
        ECHO %DEST%
        CALL :LOG "[ERROR] Cannot remove ReadOnly attribute from existing main file."
        GOTO :ERROR
    )
)
IF "%LEGACY_DETECTED%"=="1" IF EXIST "%LEGACY_DEST%" (
    ATTRIB -R "%LEGACY_DEST%" 2>NUL
    IF ERRORLEVEL 1 (
        ECHO [ERROR] �L�k�Ѱ��¦W�ۮe�ƥ�����Ū�ݩʡG
        ECHO %LEGACY_DEST%
        CALL :LOG "[ERROR] Cannot remove ReadOnly attribute from legacy compatibility file."
        GOTO :ERROR
    )
)

REM ==============================
REM 3. �ƻs�W�q��
REM ��ӥت��ɳ������ѦP�@�ӷ��إߡA�קK�D�ɻP�ۮe�ƥ��������P�B
REM ==============================
:COPY_ADDIN
ECHO.
ECHO [3/9] �ƻs�W�q��...
CALL :LOG "[STAGE] 3 - Copy"
IF "%SAME_SOURCE_DEST%"=="0" (
    COPY /Y "%SRC%" "%DEST%" >NUL 2>&1
    IF ERRORLEVEL 1 (
        ECHO [ERROR] �����D�ɽƻs���ѡC
        ECHO Source: %SRC%
        ECHO Target: %DEST%
        CALL :LOG "[ERROR] Main add-in copy failed."
        GOTO :ERROR
    )
)
IF "%LEGACY_DETECTED%"=="1" (
    COPY /Y "%SRC%" "%LEGACY_DEST%" >NUL 2>&1
    IF ERRORLEVEL 1 (
        ECHO [ERROR] �¦W�ۮe�ƥ��إߥ��ѡC
        ECHO Source: %SRC%
        ECHO Target: %LEGACY_DEST%
        CALL :LOG "[ERROR] Legacy compatibility copy failed."
        GOTO :ERROR
    )
    ECHO [OK] �����D�ɤw�N���A�¦W�ۮe�ƥ��w�إߡC
    CALL :LOG "[OK] Main and legacy compatibility files copied successfully."
) ELSE (
    ECHO [OK] �����D�ɤw�N���F�s�ϥΪ̤��إ��¦W�ۮe�ƥ��C
    CALL :LOG "[OK] Main add-in copied. Legacy compatibility copy not required."
)

REM ==============================
REM 4. MOTW / Zone.Identifier
REM ���T�{ ADS �u��s�b�A�A�P�_ ZoneId�F���A�μҽk���G���� MOTW
REM ==============================
ECHO.
ECHO [4/9] �ˬd Zone.Identifier / MOTW...
CALL :LOG "[STAGE] 4 - MOTW / Zone.Identifier"
CALL :CHECK_MOTW "%DEST%"
IF ERRORLEVEL 2 GOTO :ERROR
IF "%LEGACY_DETECTED%"=="1" CALL :CHECK_MOTW "%LEGACY_DEST%"
IF ERRORLEVEL 2 GOTO :ERROR


REM ==============================
REM �]�w�����D�ɻP�¦W�ۮe�ƥ�����Ū
REM ==============================
ATTRIB +R "%DEST%"
IF ERRORLEVEL 1 (
    ECHO [ERROR] �L�k�N�����D�ɳ]�w����Ū�G
    ECHO %DEST%
    CALL :LOG "[ERROR] Cannot set ReadOnly attribute on main file."
    GOTO :ERROR
)
IF "%LEGACY_DETECTED%"=="1" (
    ATTRIB +R "%LEGACY_DEST%"
    IF ERRORLEVEL 1 (
        ECHO [ERROR] �L�k�N�¦W�ۮe�ƥ��]�w����Ū�G
        ECHO %LEGACY_DEST%
        CALL :LOG "[ERROR] Cannot set ReadOnly attribute on legacy compatibility file."
        GOTO :ERROR
    )
    ECHO [OK] �����D�ɻP�¦W�ۮe�ƥ����w�]�w��Ū�ݩʡC
    CALL :LOG "[OK] ReadOnly attribute set on main and legacy compatibility files."
) ELSE (
    ECHO [OK] �����D�ɤw�]�w��Ū�ݩʡC
    CALL :LOG "[OK] ReadOnly attribute set on main add-in."
)


REM ==============================
REM 5. Office / Excel Policy �ˬd
REM �u�O���O�_�s�b���� Policy Key�F�s�b������@�w�|���ꥻ�W�q��
REM ==============================
ECHO.
ECHO [5/9] �ˬd Office / Excel �w���� Policy...
CALL :LOG "[STAGE] 5 - Policy"

CALL :CHECK_POLICY "HKCU\Software\Policies\Microsoft\Office\16.0\Excel\Security"
CALL :CHECK_POLICY "HKLM\Software\Policies\Microsoft\Office\16.0\Excel\Security"
CALL :CHECK_POLICY "HKLM\Software\WOW6432Node\Policies\Microsoft\Office\16.0\Excel\Security"
CALL :CHECK_POLICY "HKCU\Software\Policies\Microsoft\Office\16.0\Common\Security"
CALL :CHECK_POLICY "HKLM\Software\Policies\Microsoft\Office\16.0\Common\Security"

IF "%POLICY_FOUND%"=="1" (
    ECHO [!] Office / Excel policy keys were detected.
    ECHO     Policy presence alone does not prove the add-in is blocked. See the diagnostic file.
    CALL :LOG "[INFO] Office policy keys were detected. Presence alone does not prove blocking."
) ELSE (
    ECHO [OK] ���o�{�`�� Excel Security Policy Key�C
    CALL :LOG "[OK] No common Excel Security Policy keys detected."
)

REM ==============================
REM ������� VBA �w���]�w
REM - �Ҧ��H�G�u�� VBAWarnings=1 �ɤ~�אּ 2�F���Y��Ψ�L�]�w���ʡC
REM - �ª��ϥΪ̡G�u�� AccessVBOM=1 �ɤ~�אּ 0�A�״_�»����d�U�������n�v���C
REM - �������~ Policy �s�b�ɤ��мg�C
REM ==============================
CALL :HARDEN_SECURITY
IF ERRORLEVEL 1 GOTO :ERROR


REM ==============================
REM 6. �إ� Excel Add-in ���[�ƱҰʳ]�w�A�þE���¦W OPEN
REM �H�u�w�� Before / After ����T�{�GExcel GUI �|�b
REM HKCU\Software\Microsoft\Office\<Version>\Excel\Options
REM �إ� OPEN�BOPEN1�BOPEN2... REG_SZ�A���e���[�W���޸��� Add-in ������|�C
REM ���q�u�����o�ӥ��n���[�Ƴ]�w�A���ק��L Excel ���A�C
REM ==============================
ECHO.
ECHO [6/9] �إ� Excel Add-in ���[�ƱҰʳ]�w...
CALL :LOG "[STAGE] 6 - Persistent Add-in registration"
CALL :REGISTER_OPEN_VALUE
IF NOT "%REGISTER_OK%"=="1" GOTO :ERROR

IF /I "%REGISTER_ACTION%"=="EXISTS" (
    ECHO [OK] CJPsAddin �w�s�b�� Excel �Ұʳ]�w�G%OPEN_VALUE_NAME%
    CALL :LOG "[OK] Main add-in path already exists in %OPEN_VALUE_NAME%."
) ELSE IF /I "%REGISTER_ACTION%"=="MIGRATED" (
    ECHO [OK] �w�N�¦W Excel �Ұʳ]�w�E���� CJPsAddin�G%OPEN_VALUE_NAME%
    CALL :LOG "[OK] Legacy OPEN registration migrated to main add-in in %OPEN_VALUE_NAME%."
) ELSE (
    ECHO [OK] �w�إ� CJPsAddin Excel �Ұʳ]�w�G%OPEN_VALUE_NAME%
    CALL :LOG "[OK] Main add-in path added to %OPEN_VALUE_NAME%."
)


REM ==============================
REM 7. �ֳt�s���u��C QAT
REM �s�ϥΪ̡G�ɤW 3 �ӹw�]�\���̫e���F�¨ϥΪ̡G�u�E�������V�� Add-in �����s�C
REM QAT ���K�Q�\��A���Ѥ��v�T�֤߼W�q���w�ˡF�Բӵ��G�g�J�E�_���i�C
REM ==============================
ECHO.
ECHO [7/9] �]�w Excel �ֳt�s���u��C...
CALL :LOG "[STAGE] 7 - Quick Access Toolbar"
CALL :UPDATE_QAT
IF ERRORLEVEL 1 (
    ECHO [WARNING] �ֳt�s���u��C����۰ʧ����]�w�A�W�q���w�ˤ��|�~��C
    CALL :LOG "[WARNING] QAT update failed; core add-in installation continues."
) ELSE (
    IF "%LEGACY_DETECTED%"=="1" (
        ECHO [OK] �w�ˬd�þE���ª��ֳt�s���u��C���s�C
    ) ELSE (
        ECHO [OK] �w�T�{ 3 �� CJPsAddin �`�Υ\����ֳt�s���u��C�e��C
    )
)


REM ==============================
REM 8. �N�w�˸�Ƨ��[�J Excel Trusted Location
REM ���� VBA �İ��μҦ��ɡACJPsAddin ���i�Ѧ����H����m���`����C
REM ==============================
ECHO.
ECHO [8/9] �]�w Excel �H����m...
CALL :LOG "[STAGE] 8 - Trusted Location"
CALL :ADD_TRUSTED_LOCATION
IF ERRORLEVEL 1 GOTO :ERROR
ECHO [OK] �w�T�{ Excel �H����m�G%DEST_DIR%\
CALL :LOG "[OK] Excel Trusted Location verified: %DEST_DIR%\"

REM ==============================
REM 9. �̲�����
REM ==============================
ECHO.
ECHO [9/9] �̲�����...
CALL :LOG "[STAGE] 9 - Final verification"
IF NOT EXIST "%DEST%" (
    ECHO [ERROR] �����D�ɤ��s�b�G%DEST%
    CALL :LOG "[ERROR] Main destination file is missing during final verification."
    GOTO :ERROR
)
IF "%LEGACY_DETECTED%"=="1" IF NOT EXIST "%LEGACY_DEST%" (
    ECHO [ERROR] �¦W�ۮe�ƥ����s�b�G%LEGACY_DEST%
    CALL :LOG "[ERROR] Legacy compatibility file is missing during final verification."
    GOTO :ERROR
)
IF NOT "%REGISTER_OK%"=="1" (
    ECHO [ERROR] Excel ���[�ƱҰʳ]�w���q�L���ҡC
    CALL :LOG "[ERROR] Persistent Excel OPEN registration was not verified."
    GOTO :ERROR
)
IF NOT "%TRUST_OK%"=="1" (
    ECHO [ERROR] Excel �H����m���q�L���ҡC
    CALL :LOG "[ERROR] Excel Trusted Location was not verified."
    GOTO :ERROR
)

IF "%LEGACY_DETECTED%"=="1" (
    ECHO [OK] �����D�ɡB�¦W�ۮe�ƥ��BOPEN �P�H����m���w�T�{�C
    CALL :LOG "[OK] Main file, legacy compatibility file, OPEN registration and Trusted Location verified."
) ELSE (
    ECHO [OK] �����D�ɡBOPEN �P�H����m���w�T�{�C
    CALL :LOG "[OK] Main file, OPEN registration and Trusted Location verified."
)
GOTO :SUCCESS


REM ===============================================================================
REM ���\
REM ===============================================================================
:SUCCESS
ECHO.
ECHO ==========================================
ECHO  CJPsAddin v1.12 �w�˧���
ECHO.
ECHO  �����D�ɡG%DEST%
IF "%LEGACY_DETECTED%"=="1" ECHO  �¦W�ۮe�G%LEGACY_DEST%
ECHO  Excel �Ұʳ]�w�G%OPEN_VALUE_NAME%
ECHO  Excel �H����m�G%DEST_DIR%\
IF "%QAT_OK%"=="1" (ECHO  �ֳt�s���u��C�G�w�B�z) ELSE (ECHO  �ֳt�s���u��C�G�������A�аѦҶE�_���i)
ECHO  �ɮ��ݩʡG��Ū
ECHO.
IF "%LEGACY_DETECTED%"=="1" ECHO  �w�����ª��ۮe�P�w���]�w�E���C
ECHO  �Э��s�Ұ� Excel�A�T�{ CJPsAddin �i���`�ϥΡC
ECHO ==========================================
ECHO.
CALL :LOG ""
CALL :LOG "RESULT: SUCCESS"
CALL :LOG "=============================================================================="
CALL :CLEAN_TEMP
PAUSE
ENDLOCAL
EXIT /B 0

REM ===============================================================================
REM �@����~�X�f
REM ===============================================================================
:ERROR
ECHO.
ECHO ==========================================
ECHO  �w�˥��ѡC
ECHO ==========================================
ECHO.
ECHO �E�_���i�G%DIAG_FILE%
CALL :LOG "RESULT: INSTALLATION ERROR"
CALL :CLEAN_TEMP
PAUSE
ENDLOCAL
EXIT /B 1

:ERROR_NO_LOG
ECHO.
ECHO ==========================================
ECHO  �w�˦b�إ߶E�_���i�e�Y���ѡC
ECHO ==========================================
ECHO.
CALL :CLEAN_TEMP
PAUSE
ENDLOCAL
EXIT /B 1

:CANCEL
CALL :CLEAN_TEMP
ENDLOCAL
EXIT /B 0


REM ===============================================================================
REM DETECT_LEGACY
REM �ª��P�_����G
REM   1. �¦W�����ɦs�b�F�B
REM   2. Excel Options �� OPEN / OPEN1...OPEN99 ���ޥ��¦W������|�C
REM ��̬Ҧ��ߤ~�����ª����ҡC
REM ===============================================================================
:DETECT_LEGACY
SET "LEGACY_DETECTED=0"
SET "LEGACY_FILE_FOUND=0"
SET "LEGACY_OPEN_FOUND=0"
IF EXIST "%LEGACY_DEST%" SET "LEGACY_FILE_FOUND=1"
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
>"%VBS_FILE%" ECHO Option Explicit
>>"%VBS_FILE%" ECHO Dim sh, fso, ts, ver, legacyP, resultPath, root, i, valueName, v, cleanV, q, found
>>"%VBS_FILE%" ECHO ver = WScript.Arguments(0)
>>"%VBS_FILE%" ECHO legacyP = WScript.Arguments(1)
>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(2)
>>"%VBS_FILE%" ECHO root = "HKCU\Software\Microsoft\Office\" ^& ver ^& "\Excel\Options\"
>>"%VBS_FILE%" ECHO q = Chr(34)
>>"%VBS_FILE%" ECHO found = False
>>"%VBS_FILE%" ECHO Set sh = CreateObject("WScript.Shell")
>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS_FILE%" ECHO For i = 0 To 99
>>"%VBS_FILE%" ECHO   If i = 0 Then valueName = "OPEN" Else valueName = "OPEN" ^& CStr(i)
>>"%VBS_FILE%" ECHO   On Error Resume Next
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   v = sh.RegRead(root ^& valueName)
>>"%VBS_FILE%" ECHO   If Err.Number = 0 Then
>>"%VBS_FILE%" ECHO     cleanV = Trim(CStr(v))
>>"%VBS_FILE%" ECHO     If Len(cleanV) ^>= 2 Then If Left(cleanV, 1) = q And Right(cleanV, 1) = q Then cleanV = Mid(cleanV, 2, Len(cleanV) - 2)
>>"%VBS_FILE%" ECHO     If LCase(cleanV) = LCase(legacyP) Then found = True
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   On Error GoTo 0
>>"%VBS_FILE%" ECHO Next
>>"%VBS_FILE%" ECHO Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO If found Then ts.WriteLine "FOUND" Else ts.WriteLine "NOT_FOUND"
>>"%VBS_FILE%" ECHO ts.Close
CSCRIPT //NoLogo "%VBS_FILE%" "%EXCEL_VERSION%" "%LEGACY_DEST%" "%ADDIN_RESULT%" >"%VBS_LOG%" 2>&1
SET "LEGACY_RC=%ERRORLEVEL%"
IF NOT "%LEGACY_RC%"=="0" (
    IF EXIST "%VBS_LOG%" FOR /F "usebackq delims=" %%L IN ("%VBS_LOG%") DO CALL :LOG "[LEGACY VBS] %%L"
    CALL :LOG "[ERROR] Legacy detection helper failed. ExitCode=%LEGACY_RC%"
    DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
    EXIT /B 1
)
IF NOT EXIST "%ADDIN_RESULT%" (
    CALL :LOG "[ERROR] Legacy detection produced no result file."
    DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
    EXIT /B 1
)
SET "LEGACY_LINE="
SET /P LEGACY_LINE=<"%ADDIN_RESULT%"
IF /I "%LEGACY_LINE%"=="FOUND" SET "LEGACY_OPEN_FOUND=1"
IF "%LEGACY_FILE_FOUND%"=="1" IF "%LEGACY_OPEN_FOUND%"=="1" SET "LEGACY_DETECTED=1"
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
EXIT /B 0

REM ===============================================================================
REM HARDEN_SECURITY
REM �u����w�����w���]�w�A����e��L�J���]�w�C
REM   - VBAWarnings=1 -> 2�]�Ҧ��ϥΪ̡^
REM   - AccessVBOM=1 -> 0�]���ª����ҡ^
REM �Y�������~ Policy �w���T�]�w�ӭȡA�h���ק� HKCU �@��]�w�C
REM ===============================================================================
:HARDEN_SECURITY
SET "SECURITY_OK=0"
SET "VBA_WARNINGS_ACTION=UNCHANGED"
SET "ACCESSVBOM_ACTION=UNCHANGED"
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
>"%VBS_FILE%" ECHO Option Explicit
>>"%VBS_FILE%" ECHO Dim sh, fso, ts, ver, legacyMode, resultPath, baseKey, v, rc, actionVBA, actionVBOM, polVBA, polVBOM
>>"%VBS_FILE%" ECHO ver = WScript.Arguments(0)
>>"%VBS_FILE%" ECHO legacyMode = WScript.Arguments(1)
>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(2)
>>"%VBS_FILE%" ECHO baseKey = "HKCU\Software\Microsoft\Office\" ^& ver ^& "\Excel\Security\"
>>"%VBS_FILE%" ECHO Set sh = CreateObject("WScript.Shell")
>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS_FILE%" ECHO rc = 0
>>"%VBS_FILE%" ECHO actionVBA = "UNCHANGED"
>>"%VBS_FILE%" ECHO actionVBOM = "UNCHANGED"
>>"%VBS_FILE%" ECHO polVBA = False
>>"%VBS_FILE%" ECHO polVBOM = False
>>"%VBS_FILE%" ECHO On Error Resume Next
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKCU\Software\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\VBAWarnings")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBA = True
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKLM\Software\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\VBAWarnings")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBA = True
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKLM\Software\WOW6432Node\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\VBAWarnings")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBA = True
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKCU\Software\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\AccessVBOM")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBOM = True
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKLM\Software\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\AccessVBOM")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBOM = True
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO v = sh.RegRead("HKLM\Software\WOW6432Node\Policies\Microsoft\Office\" ^& ver ^& "\Excel\Security\AccessVBOM")
>>"%VBS_FILE%" ECHO If Err.Number = 0 Then polVBOM = True
>>"%VBS_FILE%" ECHO On Error GoTo 0
>>"%VBS_FILE%" ECHO If polVBA Then
>>"%VBS_FILE%" ECHO   actionVBA = "POLICY"
>>"%VBS_FILE%" ECHO Else
>>"%VBS_FILE%" ECHO   On Error Resume Next
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   v = sh.RegRead(baseKey ^& "VBAWarnings")
>>"%VBS_FILE%" ECHO   If Err.Number = 0 Then
>>"%VBS_FILE%" ECHO     If CLng(v) = 1 Then
>>"%VBS_FILE%" ECHO       Err.Clear
>>"%VBS_FILE%" ECHO       sh.RegWrite baseKey ^& "VBAWarnings", 2, "REG_DWORD"
>>"%VBS_FILE%" ECHO       If Err.Number ^<^> 0 Then rc = 10 Else actionVBA = "1_TO_2"
>>"%VBS_FILE%" ECHO     End If
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   On Error GoTo 0
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO If legacyMode = "1" Then
>>"%VBS_FILE%" ECHO   If polVBOM Then
>>"%VBS_FILE%" ECHO     actionVBOM = "POLICY"
>>"%VBS_FILE%" ECHO   Else
>>"%VBS_FILE%" ECHO     On Error Resume Next
>>"%VBS_FILE%" ECHO     Err.Clear
>>"%VBS_FILE%" ECHO     v = sh.RegRead(baseKey ^& "AccessVBOM")
>>"%VBS_FILE%" ECHO     If Err.Number = 0 Then
>>"%VBS_FILE%" ECHO       If CLng(v) = 1 Then
>>"%VBS_FILE%" ECHO         Err.Clear
>>"%VBS_FILE%" ECHO         sh.RegWrite baseKey ^& "AccessVBOM", 0, "REG_DWORD"
>>"%VBS_FILE%" ECHO         If Err.Number ^<^> 0 Then rc = 11 Else actionVBOM = "1_TO_0"
>>"%VBS_FILE%" ECHO       End If
>>"%VBS_FILE%" ECHO     End If
>>"%VBS_FILE%" ECHO     On Error GoTo 0
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO ts.WriteLine "RESULT;" ^& CStr(rc) ^& ";" ^& actionVBA ^& ";" ^& actionVBOM
>>"%VBS_FILE%" ECHO ts.Close
>>"%VBS_FILE%" ECHO WScript.Quit rc
CSCRIPT //NoLogo "%VBS_FILE%" "%EXCEL_VERSION%" "%LEGACY_DETECTED%" "%ADDIN_RESULT%" >"%VBS_LOG%" 2>&1
SET "SECURITY_RC=%ERRORLEVEL%"
IF EXIST "%VBS_LOG%" FOR /F "usebackq delims=" %%L IN ("%VBS_LOG%") DO CALL :LOG "[SECURITY VBS] %%L"
IF NOT EXIST "%ADDIN_RESULT%" (
    CALL :LOG "[ERROR] Security helper produced no result file. ExitCode=%SECURITY_RC%"
    DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
    EXIT /B 1
)
SET "SECURITY_LINE="
SET /P SECURITY_LINE=<"%ADDIN_RESULT%"
CALL :LOG "[SECURITY] %SECURITY_LINE%"
FOR /F "tokens=1-4 delims=;" %%A IN ("%SECURITY_LINE%") DO (
    IF /I "%%A"=="RESULT" (
        SET "VBA_WARNINGS_ACTION=%%C"
        SET "ACCESSVBOM_ACTION=%%D"
    )
)
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
IF NOT "%SECURITY_RC%"=="0" EXIT /B 1
SET "SECURITY_OK=1"
IF /I "%VBA_WARNINGS_ACTION%"=="1_TO_2" (
    ECHO [OK] �w�N Excel �q�u�ҥΩҦ� VBA �����v�վ㬰�u���� VBA �����]�ƥ��q���^�v�C
    CALL :LOG "[OK] VBAWarnings changed from 1 to 2."
) ELSE IF /I "%VBA_WARNINGS_ACTION%"=="POLICY" (
    ECHO [INFO] VBA �����w���ʥѥ��~ Policy �޲z�A���{�����ק�C
    CALL :LOG "[INFO] VBAWarnings is managed by policy; no user setting changed."
) ELSE (
    CALL :LOG "[INFO] VBAWarnings did not require tightening."
)
IF "%LEGACY_DETECTED%"=="1" (
    IF /I "%ACCESSVBOM_ACTION%"=="1_TO_0" (
        ECHO [OK] �w���Ρu�H���s�� VBA �M�ת���ҫ��v�C
        CALL :LOG "[OK] AccessVBOM changed from 1 to 0 for legacy migration."
    ) ELSE IF /I "%ACCESSVBOM_ACTION%"=="POLICY" (
        ECHO [INFO] VBA �M�ת���ҫ��s���ѥ��~ Policy �޲z�A���{�����ק�C
        CALL :LOG "[INFO] AccessVBOM is managed by policy; no user setting changed."
    ) ELSE (
        CALL :LOG "[INFO] AccessVBOM did not require legacy remediation."
    )
)
EXIT /B 0

REM ===============================================================================
REM REGISTER_OPEN_VALUE
REM �H�� ASCII VBS �B�z Registry�A�קK CMD quoting / ������|�z�Z�C
REM �W�h�G
REM   1. �Y�w�� CJPsAddin.xla ���|�G�O�d�� OPEN�A�ò���������V�¦W�ƥ��� OPEN�C
REM   2. �Y�S���s���|�B�����¦W OPEN�G�����b�� OPEN �W�٤W��g�� CJPsAddin.xla�A�^�� MIGRATED�C
REM   3. �s�³��S���G�ϥβĤ@�ӥi�� OPEN / OPEN1...OPEN99�A�^�� ADDED�C
REM   4. �¦W�ۮe�ƥ��u�O�d�����ɡA���O�d Excel OPEN �ޥΡC
REM   5. �Ҧ��g�J�ΧR�����H RegRead �A�T�{���G�C
REM ===============================================================================
:REGISTER_OPEN_VALUE
SET "REGISTER_OK=0"
SET "REGISTER_ACTION="
SET "OPEN_VALUE_NAME="
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL

>"%VBS_FILE%" ECHO Option Explicit
>>"%VBS_FILE%" ECHO Dim sh, fso, ts, ver, p, legacyP, resultPath, root, i, valueName, v, firstFree, cleanV, q, rc, mainName, legacyName
>>"%VBS_FILE%" ECHO ver = WScript.Arguments(0)
>>"%VBS_FILE%" ECHO p = WScript.Arguments(1)
>>"%VBS_FILE%" ECHO legacyP = WScript.Arguments(2)
>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(3)
>>"%VBS_FILE%" ECHO root = "HKCU\Software\Microsoft\Office\" ^& ver ^& "\Excel\Options\"
>>"%VBS_FILE%" ECHO q = Chr(34)
>>"%VBS_FILE%" ECHO firstFree = ""
>>"%VBS_FILE%" ECHO mainName = ""
>>"%VBS_FILE%" ECHO legacyName = ""
>>"%VBS_FILE%" ECHO rc = 0
>>"%VBS_FILE%" ECHO Set sh = CreateObject("WScript.Shell")
>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS_FILE%" ECHO For i = 0 To 99
>>"%VBS_FILE%" ECHO   If i = 0 Then valueName = "OPEN" Else valueName = "OPEN" ^& CStr(i)
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   On Error Resume Next
>>"%VBS_FILE%" ECHO   v = sh.RegRead(root ^& valueName)
>>"%VBS_FILE%" ECHO   If Err.Number ^<^> 0 Then
>>"%VBS_FILE%" ECHO     If firstFree = "" Then firstFree = valueName
>>"%VBS_FILE%" ECHO     Err.Clear
>>"%VBS_FILE%" ECHO   Else
>>"%VBS_FILE%" ECHO     cleanV = Trim(CStr(v))
>>"%VBS_FILE%" ECHO     If Len(cleanV) ^>= 2 Then
>>"%VBS_FILE%" ECHO       If Left(cleanV, 1) = q And Right(cleanV, 1) = q Then cleanV = Mid(cleanV, 2, Len(cleanV) - 2)
>>"%VBS_FILE%" ECHO     End If
>>"%VBS_FILE%" ECHO     If LCase(cleanV) = LCase(p) Then mainName = valueName
>>"%VBS_FILE%" ECHO     If LCase(cleanV) = LCase(legacyP) Then
>>"%VBS_FILE%" ECHO       If legacyName = "" Then
>>"%VBS_FILE%" ECHO         legacyName = valueName
>>"%VBS_FILE%" ECHO       Else
>>"%VBS_FILE%" ECHO         Err.Clear
>>"%VBS_FILE%" ECHO         sh.RegDelete root ^& valueName
>>"%VBS_FILE%" ECHO         If Err.Number ^<^> 0 Then rc = 6
>>"%VBS_FILE%" ECHO       End If
>>"%VBS_FILE%" ECHO     End If
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   On Error GoTo 0
>>"%VBS_FILE%" ECHO Next
>>"%VBS_FILE%" ECHO If rc ^<^> 0 Then
>>"%VBS_FILE%" ECHO   Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO   ts.WriteLine "ERROR;LEGACY_CLEANUP;" ^& CStr(rc)
>>"%VBS_FILE%" ECHO   ts.Close
>>"%VBS_FILE%" ECHO   WScript.Quit rc
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO If mainName ^<^> "" Then
>>"%VBS_FILE%" ECHO   If legacyName ^<^> "" Then
>>"%VBS_FILE%" ECHO     On Error Resume Next
>>"%VBS_FILE%" ECHO     Err.Clear
>>"%VBS_FILE%" ECHO     sh.RegDelete root ^& legacyName
>>"%VBS_FILE%" ECHO     If Err.Number ^<^> 0 Then rc = 7
>>"%VBS_FILE%" ECHO     On Error GoTo 0
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   If rc = 0 Then
>>"%VBS_FILE%" ECHO     Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO     ts.WriteLine "OK;EXISTS;" ^& mainName
>>"%VBS_FILE%" ECHO     ts.Close
>>"%VBS_FILE%" ECHO     WScript.Quit 0
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO If legacyName ^<^> "" Then
>>"%VBS_FILE%" ECHO   On Error Resume Next
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   sh.RegWrite root ^& legacyName, q ^& p ^& q, "REG_SZ"
>>"%VBS_FILE%" ECHO   If Err.Number ^<^> 0 Then rc = 3
>>"%VBS_FILE%" ECHO   If rc = 0 Then
>>"%VBS_FILE%" ECHO     Err.Clear
>>"%VBS_FILE%" ECHO     v = sh.RegRead(root ^& legacyName)
>>"%VBS_FILE%" ECHO     If Err.Number ^<^> 0 Then rc = 4
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   On Error GoTo 0
>>"%VBS_FILE%" ECHO   If rc = 0 Then
>>"%VBS_FILE%" ECHO     cleanV = Trim(CStr(v))
>>"%VBS_FILE%" ECHO     If Len(cleanV) ^>= 2 Then If Left(cleanV, 1) = q And Right(cleanV, 1) = q Then cleanV = Mid(cleanV, 2, Len(cleanV) - 2)
>>"%VBS_FILE%" ECHO     If LCase(cleanV) ^<^> LCase(p) Then rc = 5
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO   If rc = 0 Then ts.WriteLine "OK;MIGRATED;" ^& legacyName Else ts.WriteLine "ERROR;MIGRATE_VERIFY;" ^& CStr(rc)
>>"%VBS_FILE%" ECHO   ts.Close
>>"%VBS_FILE%" ECHO   WScript.Quit rc
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO If firstFree = "" Then
>>"%VBS_FILE%" ECHO   Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO   ts.WriteLine "ERROR;NO_FREE_OPEN_VALUE"
>>"%VBS_FILE%" ECHO   ts.Close
>>"%VBS_FILE%" ECHO   WScript.Quit 2
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO On Error Resume Next
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO sh.RegWrite root ^& firstFree, q ^& p ^& q, "REG_SZ"
>>"%VBS_FILE%" ECHO If Err.Number ^<^> 0 Then rc = 3
>>"%VBS_FILE%" ECHO If rc = 0 Then
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   v = sh.RegRead(root ^& firstFree)
>>"%VBS_FILE%" ECHO   If Err.Number ^<^> 0 Then rc = 4
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO On Error GoTo 0
>>"%VBS_FILE%" ECHO If rc = 0 Then
>>"%VBS_FILE%" ECHO   cleanV = Trim(CStr(v))
>>"%VBS_FILE%" ECHO   If Len(cleanV) ^>= 2 Then If Left(cleanV, 1) = q And Right(cleanV, 1) = q Then cleanV = Mid(cleanV, 2, Len(cleanV) - 2)
>>"%VBS_FILE%" ECHO   If LCase(cleanV) ^<^> LCase(p) Then rc = 5
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO If rc = 0 Then ts.WriteLine "OK;ADDED;" ^& firstFree Else ts.WriteLine "ERROR;WRITE_VERIFY;" ^& CStr(rc)
>>"%VBS_FILE%" ECHO ts.Close
>>"%VBS_FILE%" ECHO Set ts = Nothing
>>"%VBS_FILE%" ECHO Set fso = Nothing
>>"%VBS_FILE%" ECHO Set sh = Nothing
>>"%VBS_FILE%" ECHO WScript.Quit rc

CSCRIPT //NoLogo "%VBS_FILE%" "%EXCEL_VERSION%" "%DEST%" "%LEGACY_DEST%" "%ADDIN_RESULT%" >"%VBS_LOG%" 2>&1
SET "REGISTER_RC=%ERRORLEVEL%"
IF EXIST "%VBS_LOG%" (
    FOR /F "usebackq delims=" %%L IN ("%VBS_LOG%") DO CALL :LOG "[REGISTRATION VBS] %%L"
)
IF NOT EXIST "%ADDIN_RESULT%" (
    ECHO [ERROR] Excel �Ұʳ]�w�����͵��G�ɡCExitCode=%REGISTER_RC%
    CALL :LOG "[ERROR] Persistent registration produced no result file. ExitCode=%REGISTER_RC%"
    EXIT /B 1
)

SET "REGISTER_LINE="
SET /P REGISTER_LINE=<"%ADDIN_RESULT%"
CALL :LOG "[OPEN REGISTRATION] %REGISTER_LINE%"
FOR /F "tokens=1-3 delims=;" %%A IN ("%REGISTER_LINE%") DO (
    IF /I "%%A"=="OK" (
        SET "REGISTER_OK=1"
        SET "REGISTER_ACTION=%%B"
        SET "OPEN_VALUE_NAME=%%C"
    )
)
IF NOT "%REGISTER_RC%"=="0" CALL :LOG "[INFO] Persistent registration ExitCode=%REGISTER_RC%"
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
IF "%REGISTER_OK%"=="1" EXIT /B 0
ECHO [ERROR] �L�k�إߡB�E�������� Excel ���[�ƱҰʳ]�w�C
CALL :LOG "[ERROR] Persistent Excel OPEN registration failed."
EXIT /B 1

REM ===============================================================================
REM UPDATE_QAT
REM �s�ϥΪ̡G�� Excel �H�u�إߦ��\�� CustomUI ���c�A�b QAT �̫e��ɤW 3 �� CJPsAddin �`�Ϋ��s�C
REM �¨ϥΪ̡G�u�E�� onAction �����V�� Add-in �� button�A�æP�B���� idQ�C
REM ����n�I�G
REM   - idQ �ϥ� x1 namespace�Ghttp://schemas.microsoft.com/office/2009/07/customui/macro
REM   - 3 �ӫ��s�� insertBeforeQ="mso:FileSave"
REM   - ProShowAllData �ϥܼȱ� CancelRequest�]�̭�]�p�F�H�u���մ���� Delete�^
REM �w�����I�G
REM   - �ק�J�� Excel.officeUI �e�u�إߤ@�� Excel.officeUI.CJPsAddinBackup�C
REM   - ����X�Ȧs�ɨí��s���J XML ���ҡA���\��~�мg���ɡC
REM   - �g�^��A���T�{ 3 �� onAction �P x1 namespace �u��s�b�A�~�^�����\�C
REM   - ���R���έ��ƨ�L�ϥΪ̦ۭq���s�C
REM ===============================================================================
:UPDATE_QAT
SET "QAT_OK=0"
SET "QAT_ACTION="
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL

>"%VBS_FILE%" ECHO Option Explicit

>>"%VBS_FILE%" ECHO Dim fso, dom, verifyDom, root, ribbon, qat, sharedControls, fileSaveNode, n, nodes

>>"%VBS_FILE%" ECHO Dim officePath, backupPath, tempPath, newPath, legacyName, resultPath, mode

>>"%VBS_FILE%" ECHO Dim nsMso, nsX1, action, procName, changed, added, migrated, hadFile, createdShared

>>"%VBS_FILE%" ECHO Dim procExact, procFuzzy, procShowAll, xmlText

>>"%VBS_FILE%" ECHO officePath = WScript.Arguments(0)

>>"%VBS_FILE%" ECHO backupPath = WScript.Arguments(1)

>>"%VBS_FILE%" ECHO newPath = WScript.Arguments(2)

>>"%VBS_FILE%" ECHO legacyName = WScript.Arguments(3)

>>"%VBS_FILE%" ECHO mode = UCase(WScript.Arguments(4))

>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(5)

>>"%VBS_FILE%" ECHO procExact = WScript.Arguments(6)

>>"%VBS_FILE%" ECHO procFuzzy = WScript.Arguments(7)

>>"%VBS_FILE%" ECHO procShowAll = WScript.Arguments(8)

>>"%VBS_FILE%" ECHO nsMso = "http://schemas.microsoft.com/office/2009/07/customui"

>>"%VBS_FILE%" ECHO nsX1 = "http://schemas.microsoft.com/office/2009/07/customui/macro"

>>"%VBS_FILE%" ECHO changed = 0

>>"%VBS_FILE%" ECHO added = 0

>>"%VBS_FILE%" ECHO migrated = 0

>>"%VBS_FILE%" ECHO createdShared = False

>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")

>>"%VBS_FILE%" ECHO hadFile = fso.FileExists(officePath)

>>"%VBS_FILE%" ECHO Set dom = CreateObject("Msxml2.DOMDocument.6.0")

>>"%VBS_FILE%" ECHO dom.async = False

>>"%VBS_FILE%" ECHO dom.preserveWhiteSpace = True

>>"%VBS_FILE%" ECHO If hadFile Then

>>"%VBS_FILE%" ECHO   If Not dom.Load(officePath) Then Call Finish("ERROR;XML_LOAD;" ^& CStr(dom.parseError.errorCode), 2)

>>"%VBS_FILE%" ECHO Else

>>"%VBS_FILE%" ECHO   Set root = dom.createNode(1, "mso:customUI", nsMso)

>>"%VBS_FILE%" ECHO   dom.appendChild root

>>"%VBS_FILE%" ECHO   Set ribbon = dom.createNode(1, "mso:ribbon", nsMso)

>>"%VBS_FILE%" ECHO   root.appendChild ribbon

>>"%VBS_FILE%" ECHO   Set qat = dom.createNode(1, "mso:qat", nsMso)

>>"%VBS_FILE%" ECHO   ribbon.appendChild qat

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO Set root = dom.documentElement

>>"%VBS_FILE%" ECHO If root Is Nothing Then Call Finish("ERROR;NO_ROOT", 3)

>>"%VBS_FILE%" ECHO Set ribbon = FindFirstElement(dom, "ribbon")

>>"%VBS_FILE%" ECHO If ribbon Is Nothing Then

>>"%VBS_FILE%" ECHO   Set ribbon = dom.createNode(1, QnameLike(root, "ribbon"), NsOf(root))

>>"%VBS_FILE%" ECHO   root.appendChild ribbon

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO Set qat = FindFirstElement(dom, "qat")

>>"%VBS_FILE%" ECHO If qat Is Nothing Then

>>"%VBS_FILE%" ECHO   Set qat = dom.createNode(1, QnameLike(ribbon, "qat"), NsOf(ribbon))

>>"%VBS_FILE%" ECHO   ribbon.insertBefore qat, ribbon.firstChild

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO Set sharedControls = FindFirstElement(qat, "sharedControls")

>>"%VBS_FILE%" ECHO If sharedControls Is Nothing Then

>>"%VBS_FILE%" ECHO   Set sharedControls = dom.createNode(1, QnameLike(qat, "sharedControls"), NsOf(qat))

>>"%VBS_FILE%" ECHO   qat.appendChild sharedControls

>>"%VBS_FILE%" ECHO   createdShared = True

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO If mode = "LEGACY" Then

>>"%VBS_FILE%" ECHO   Set nodes = dom.getElementsByTagName("*")

>>"%VBS_FILE%" ECHO   For Each n In nodes

>>"%VBS_FILE%" ECHO     If LCase(ElementLocalName(n)) = "button" Then

>>"%VBS_FILE%" ECHO       action = CStr(n.getAttribute("onAction"))

>>"%VBS_FILE%" ECHO       If InStr(1, action, legacyName, vbTextCompare) ^> 0 Then

>>"%VBS_FILE%" ECHO         procName = ""

>>"%VBS_FILE%" ECHO         If InStrRev(action, "!") ^> 0 Then procName = Mid(action, InStrRev(action, "!") + 1)

>>"%VBS_FILE%" ECHO         If Len(procName) ^> 0 Then

>>"%VBS_FILE%" ECHO           n.setAttribute "onAction", newPath ^& "!" ^& procName

>>"%VBS_FILE%" ECHO           n.setAttribute "idQ", BuildIdQ(newPath, procName)

>>"%VBS_FILE%" ECHO           migrated = migrated + 1

>>"%VBS_FILE%" ECHO           changed = 1

>>"%VBS_FILE%" ECHO         End If

>>"%VBS_FILE%" ECHO       End If

>>"%VBS_FILE%" ECHO     End If

>>"%VBS_FILE%" ECHO   Next

>>"%VBS_FILE%" ECHO Else

>>"%VBS_FILE%" ECHO   If createdShared Then Call AddDefaultQatControls()

>>"%VBS_FILE%" ECHO   Set fileSaveNode = FindControlByIdQ(sharedControls, "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddButtonIfMissing(procExact, "FilterByResource", fileSaveNode)

>>"%VBS_FILE%" ECHO   Call AddButtonIfMissing(procFuzzy, "FilterToggleFilter", fileSaveNode)

>>"%VBS_FILE%" ECHO   Call AddButtonIfMissing(procShowAll, "CancelRequest", fileSaveNode)

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO If changed = 0 Then

>>"%VBS_FILE%" ECHO   If mode = "LEGACY" Then Call Finish("OK;LEGACY;MIGRATED=0", 0)

>>"%VBS_FILE%" ECHO   If VerifyNewButtonsInText(ReadUtf8(officePath)) Then Call Finish("OK;NEW;ADDED=0", 0)

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO If hadFile And Not fso.FileExists(backupPath) Then fso.CopyFile officePath, backupPath, False

>>"%VBS_FILE%" ECHO tempPath = officePath ^& ".CJPsAddin.tmp"

>>"%VBS_FILE%" ECHO On Error Resume Next

>>"%VBS_FILE%" ECHO fso.DeleteFile tempPath, True

>>"%VBS_FILE%" ECHO On Error GoTo 0

>>"%VBS_FILE%" ECHO xmlText = dom.xml

>>"%VBS_FILE%" ECHO xmlText = EnsureX1Namespace(xmlText)

>>"%VBS_FILE%" ECHO Call WriteUtf8NoBom(tempPath, xmlText)

>>"%VBS_FILE%" ECHO Set verifyDom = CreateObject("Msxml2.DOMDocument.6.0")

>>"%VBS_FILE%" ECHO verifyDom.async = False

>>"%VBS_FILE%" ECHO If Not verifyDom.Load(tempPath) Then Call Finish("ERROR;XML_VERIFY;" ^& CStr(verifyDom.parseError.errorCode), 4)

>>"%VBS_FILE%" ECHO If mode = "NEW" Then

>>"%VBS_FILE%" ECHO   If Not VerifyNewButtonsInText(ReadUtf8(tempPath)) Then Call Finish("ERROR;QAT_VERIFY;BUTTONS_NOT_FOUND", 6)

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO On Error Resume Next

>>"%VBS_FILE%" ECHO Err.Clear

>>"%VBS_FILE%" ECHO fso.CopyFile tempPath, officePath, True

>>"%VBS_FILE%" ECHO If Err.Number ^<^> 0 Then Call Finish("ERROR;WRITE;" ^& CStr(Err.Number), 5)

>>"%VBS_FILE%" ECHO On Error GoTo 0

>>"%VBS_FILE%" ECHO fso.DeleteFile tempPath, True

>>"%VBS_FILE%" ECHO If mode = "NEW" Then

>>"%VBS_FILE%" ECHO   If Not VerifyNewButtonsInText(ReadUtf8(officePath)) Then Call Finish("ERROR;FINAL_VERIFY;BUTTONS_NOT_FOUND", 7)

>>"%VBS_FILE%" ECHO End If

>>"%VBS_FILE%" ECHO If mode = "LEGACY" Then Call Finish("OK;LEGACY;MIGRATED=" ^& CStr(migrated), 0)

>>"%VBS_FILE%" ECHO Call Finish("OK;NEW;ADDED=" ^& CStr(added), 0)

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Sub AddDefaultQatControls()

>>"%VBS_FILE%" ECHO   Call AddControl("mso:FileNewDefault", "false", "")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:FileOpenUsingBackstage", "false", "")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:FileSendAsAttachment", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:FilePrintQuick", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:PrintPreviewAndPrint", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:Spelling", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:SortAscendingExcel", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:SortDescendingExcel", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:PointerModeOptions", "false", "mso:FileSave")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:FileSave", "true", "")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:Undo", "true", "")

>>"%VBS_FILE%" ECHO   Call AddControl("mso:Redo", "true", "")

>>"%VBS_FILE%" ECHO End Sub

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Sub AddControl(controlId, visibleValue, beforeId)

>>"%VBS_FILE%" ECHO   Dim ctl

>>"%VBS_FILE%" ECHO   Set ctl = dom.createNode(1, QnameLike(sharedControls, "control"), NsOf(sharedControls))

>>"%VBS_FILE%" ECHO   ctl.setAttribute "idQ", controlId

>>"%VBS_FILE%" ECHO   ctl.setAttribute "visible", visibleValue

>>"%VBS_FILE%" ECHO   If Len(beforeId) ^> 0 Then ctl.setAttribute "insertBeforeQ", beforeId

>>"%VBS_FILE%" ECHO   sharedControls.appendChild ctl

>>"%VBS_FILE%" ECHO End Sub

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Sub AddButtonIfMissing(proc, img, beforeNode)

>>"%VBS_FILE%" ECHO   Dim list, item, a, btn

>>"%VBS_FILE%" ECHO   a = newPath ^& "!" ^& proc

>>"%VBS_FILE%" ECHO   Set list = dom.getElementsByTagName("*")

>>"%VBS_FILE%" ECHO   For Each item In list

>>"%VBS_FILE%" ECHO     If LCase(ElementLocalName(item)) = "button" Then

>>"%VBS_FILE%" ECHO       If StrComp(CStr(item.getAttribute("onAction")), a, vbTextCompare) = 0 Then Exit Sub

>>"%VBS_FILE%" ECHO     End If

>>"%VBS_FILE%" ECHO   Next

>>"%VBS_FILE%" ECHO   Set btn = dom.createNode(1, QnameLike(sharedControls, "button"), NsOf(sharedControls))

>>"%VBS_FILE%" ECHO   btn.setAttribute "idQ", BuildIdQ(newPath, proc)

>>"%VBS_FILE%" ECHO   btn.setAttribute "visible", "true"

>>"%VBS_FILE%" ECHO   btn.setAttribute "label", proc

>>"%VBS_FILE%" ECHO   btn.setAttribute "imageMso", img

>>"%VBS_FILE%" ECHO   btn.setAttribute "onAction", a

>>"%VBS_FILE%" ECHO   btn.setAttribute "insertBeforeQ", "mso:FileSave"

>>"%VBS_FILE%" ECHO   If Not beforeNode Is Nothing Then

>>"%VBS_FILE%" ECHO     sharedControls.insertBefore btn, beforeNode

>>"%VBS_FILE%" ECHO   Else

>>"%VBS_FILE%" ECHO     sharedControls.appendChild btn

>>"%VBS_FILE%" ECHO   End If

>>"%VBS_FILE%" ECHO   added = added + 1

>>"%VBS_FILE%" ECHO   changed = 1

>>"%VBS_FILE%" ECHO End Sub

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function FindControlByIdQ(parentNode, controlId)

>>"%VBS_FILE%" ECHO   Dim list, item

>>"%VBS_FILE%" ECHO   Set FindControlByIdQ = Nothing

>>"%VBS_FILE%" ECHO   Set list = parentNode.childNodes

>>"%VBS_FILE%" ECHO   For Each item In list

>>"%VBS_FILE%" ECHO     If item.nodeType = 1 Then

>>"%VBS_FILE%" ECHO       If StrComp(CStr(item.getAttribute("idQ")), controlId, vbTextCompare) = 0 Then

>>"%VBS_FILE%" ECHO         Set FindControlByIdQ = item

>>"%VBS_FILE%" ECHO         Exit Function

>>"%VBS_FILE%" ECHO       End If

>>"%VBS_FILE%" ECHO     End If

>>"%VBS_FILE%" ECHO   Next

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function FindFirstElement(parentNode, localName)

>>"%VBS_FILE%" ECHO   Dim list, item

>>"%VBS_FILE%" ECHO   Set FindFirstElement = Nothing

>>"%VBS_FILE%" ECHO   Set list = parentNode.getElementsByTagName("*")

>>"%VBS_FILE%" ECHO   For Each item In list

>>"%VBS_FILE%" ECHO     If StrComp(ElementLocalName(item), localName, vbTextCompare) = 0 Then

>>"%VBS_FILE%" ECHO       Set FindFirstElement = item

>>"%VBS_FILE%" ECHO       Exit Function

>>"%VBS_FILE%" ECHO     End If

>>"%VBS_FILE%" ECHO   Next

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function ElementLocalName(node)

>>"%VBS_FILE%" ECHO   Dim s

>>"%VBS_FILE%" ECHO   s = ""

>>"%VBS_FILE%" ECHO   On Error Resume Next

>>"%VBS_FILE%" ECHO   s = CStr(node.baseName)

>>"%VBS_FILE%" ECHO   On Error GoTo 0

>>"%VBS_FILE%" ECHO   If Len(s) = 0 Then s = CStr(node.nodeName)

>>"%VBS_FILE%" ECHO   If InStr(s, ":") ^> 0 Then s = Mid(s, InStr(s, ":") + 1)

>>"%VBS_FILE%" ECHO   ElementLocalName = s

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function NsOf(node)

>>"%VBS_FILE%" ECHO   Dim s

>>"%VBS_FILE%" ECHO   s = ""

>>"%VBS_FILE%" ECHO   On Error Resume Next

>>"%VBS_FILE%" ECHO   s = CStr(node.namespaceURI)

>>"%VBS_FILE%" ECHO   On Error GoTo 0

>>"%VBS_FILE%" ECHO   If Len(s) = 0 Then s = nsMso

>>"%VBS_FILE%" ECHO   NsOf = s

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function QnameLike(node, localName)

>>"%VBS_FILE%" ECHO   Dim p

>>"%VBS_FILE%" ECHO   p = ""

>>"%VBS_FILE%" ECHO   On Error Resume Next

>>"%VBS_FILE%" ECHO   p = CStr(node.prefix)

>>"%VBS_FILE%" ECHO   On Error GoTo 0

>>"%VBS_FILE%" ECHO   If Len(p) ^> 0 Then QnameLike = p ^& ":" ^& localName Else QnameLike = "mso:" ^& localName

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function BuildIdQ(p, proc)

>>"%VBS_FILE%" ECHO   Dim s

>>"%VBS_FILE%" ECHO   s = Replace(p, "\", "_")

>>"%VBS_FILE%" ECHO   s = Replace(s, " ", "_")

>>"%VBS_FILE%" ECHO   s = Replace(s, "!", "_")

>>"%VBS_FILE%" ECHO   BuildIdQ = "x1:" ^& s ^& "_" ^& proc ^& "_1"

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function EnsureX1Namespace(s)

>>"%VBS_FILE%" ECHO   Dim marker, openTag

>>"%VBS_FILE%" ECHO   marker = "xmlns:x1=""" ^& nsX1 ^& """"

>>"%VBS_FILE%" ECHO   If InStr(1, s, marker, vbTextCompare) = 0 Then

>>"%VBS_FILE%" ECHO     openTag = Chr(60) ^& "mso:customUI"

>>"%VBS_FILE%" ECHO     If InStr(1, s, openTag, vbTextCompare) ^> 0 Then

>>"%VBS_FILE%" ECHO       s = Replace(s, openTag, openTag ^& " " ^& marker, 1, 1, vbTextCompare)

>>"%VBS_FILE%" ECHO     Else

>>"%VBS_FILE%" ECHO       openTag = Chr(60) ^& "customUI"

>>"%VBS_FILE%" ECHO       s = Replace(s, openTag, openTag ^& " " ^& marker, 1, 1, vbTextCompare)

>>"%VBS_FILE%" ECHO     End If

>>"%VBS_FILE%" ECHO   End If

>>"%VBS_FILE%" ECHO   EnsureX1Namespace = s

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function VerifyNewButtonsInText(s)

>>"%VBS_FILE%" ECHO   VerifyNewButtonsInText = _

>>"%VBS_FILE%" ECHO     (InStr(1, s, newPath ^& "!" ^& procExact, vbTextCompare) ^> 0) And _

>>"%VBS_FILE%" ECHO     (InStr(1, s, newPath ^& "!" ^& procFuzzy, vbTextCompare) ^> 0) And _

>>"%VBS_FILE%" ECHO     (InStr(1, s, newPath ^& "!" ^& procShowAll, vbTextCompare) ^> 0) And _

>>"%VBS_FILE%" ECHO     (InStr(1, s, "xmlns:x1=""" ^& nsX1 ^& """", vbTextCompare) ^> 0)

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Function ReadUtf8(path)

>>"%VBS_FILE%" ECHO   Dim stm

>>"%VBS_FILE%" ECHO   Set stm = CreateObject("ADODB.Stream")

>>"%VBS_FILE%" ECHO   stm.Type = 2

>>"%VBS_FILE%" ECHO   stm.Charset = "utf-8"

>>"%VBS_FILE%" ECHO   stm.Open

>>"%VBS_FILE%" ECHO   stm.LoadFromFile path

>>"%VBS_FILE%" ECHO   ReadUtf8 = stm.ReadText

>>"%VBS_FILE%" ECHO   stm.Close

>>"%VBS_FILE%" ECHO End Function

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Sub WriteUtf8NoBom(path, textValue)

>>"%VBS_FILE%" ECHO   Dim txt, bin

>>"%VBS_FILE%" ECHO   Set txt = CreateObject("ADODB.Stream")

>>"%VBS_FILE%" ECHO   txt.Type = 2

>>"%VBS_FILE%" ECHO   txt.Charset = "utf-8"

>>"%VBS_FILE%" ECHO   txt.Open

>>"%VBS_FILE%" ECHO   txt.WriteText textValue

>>"%VBS_FILE%" ECHO   txt.Position = 3

>>"%VBS_FILE%" ECHO   Set bin = CreateObject("ADODB.Stream")

>>"%VBS_FILE%" ECHO   bin.Type = 1

>>"%VBS_FILE%" ECHO   bin.Open

>>"%VBS_FILE%" ECHO   txt.CopyTo bin

>>"%VBS_FILE%" ECHO   bin.SaveToFile path, 2

>>"%VBS_FILE%" ECHO   bin.Close

>>"%VBS_FILE%" ECHO   txt.Close

>>"%VBS_FILE%" ECHO End Sub

>>"%VBS_FILE%" ECHO.

>>"%VBS_FILE%" ECHO Sub Finish(msg, rc)

>>"%VBS_FILE%" ECHO   Dim ts

>>"%VBS_FILE%" ECHO   Set ts = fso.CreateTextFile(resultPath, True, False)

>>"%VBS_FILE%" ECHO   ts.WriteLine msg

>>"%VBS_FILE%" ECHO   ts.Close

>>"%VBS_FILE%" ECHO   WScript.Quit rc

>>"%VBS_FILE%" ECHO End Sub

IF "%LEGACY_DETECTED%"=="1" (SET "QAT_MODE=LEGACY") ELSE (SET "QAT_MODE=NEW")
CSCRIPT //NoLogo "%VBS_FILE%" "%QAT_FILE%" "%QAT_BACKUP%" "%DEST%" "%LEGACY_FILE%" "%QAT_MODE%" "%ADDIN_RESULT%" "�z��j��_�������" "�z��j��_�ҽk���" "ProShowAllData" >"%VBS_LOG%" 2>&1
SET "QAT_RC=%ERRORLEVEL%"
IF EXIST "%VBS_LOG%" (
    FOR /F "usebackq delims=" %%L IN ("%VBS_LOG%") DO CALL :LOG "[QAT VBS] %%L"
)
IF NOT EXIST "%ADDIN_RESULT%" (
    CALL :LOG "[ERROR] QAT helper produced no result file. ExitCode=%QAT_RC%"
    MOVE /Y "%VBS_FILE%" "%QAT_DEBUG%" >NUL 2>&1
    IF EXIST "%QAT_DEBUG%" (
        CALL :LOG "[INFO] QAT helper source saved for debugging: %QAT_DEBUG%"
    ) ELSE (
        CALL :LOG "[WARNING] QAT helper source could not be preserved for debugging."
    )
    DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
    EXIT /B 1
)
SET "QAT_LINE="
SET /P QAT_LINE=<"%ADDIN_RESULT%"
CALL :LOG "[QAT] %QAT_LINE%"
FOR /F "tokens=1-3 delims=;" %%A IN ("%QAT_LINE%") DO (
    IF /I "%%A"=="OK" (
        SET "QAT_OK=1"
        SET "QAT_ACTION=%%B;%%C"
    )
)
IF NOT "%QAT_RC%"=="0" CALL :LOG "[INFO] QAT helper ExitCode=%QAT_RC%"
IF NOT "%QAT_OK%"=="1" (
    MOVE /Y "%VBS_FILE%" "%QAT_DEBUG%" >NUL 2>&1
    IF EXIST "%QAT_DEBUG%" (
        CALL :LOG "[INFO] QAT helper source saved for debugging: %QAT_DEBUG%"
    ) ELSE (
        CALL :LOG "[WARNING] QAT helper source could not be preserved for debugging."
    )
)
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
IF "%QAT_OK%"=="1" EXIT /B 0
EXIT /B 1


REM ===============================================================================
REM ADD_TRUSTED_LOCATION
REM �w�ˮɩT�w�I�s�F�Ψ��� CJPsAddin �b���� VBA �������ήɤ��i���`����C
REM �H�� ASCII VBS �g�J HKCU �� Excel Trusted Locations�A�קK REG ADD quoting ���D�C
REM �W�h�G
REM   1. ����O�_�w�s�b�ۦP Path�F�s�b�N�����^���\�C
REM   2. ���s�b�h��Ĥ@�ӥi�� Location0...Location99�C
REM   3. Path �T�w���W�Ƭ����ݤ@�Ӥϱ׽u�C
REM   4. Description �T�w���uCJPsAddin �w�˦�m�]�� Installer �إߡ^�v�F�J���ۦP Path �]�P�B��s�C
REM   5. �g�J Path / Description / AllowSubFolders=0 ��ߧY RegRead ���ҡC
REM ===============================================================================
:ADD_TRUSTED_LOCATION
SET "TRUST_OK=0"
SET "TRUST_ACTION="
SET "TRUST_LOCATION_NAME="
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL

>"%VBS_FILE%" ECHO Option Explicit
>>"%VBS_FILE%" ECHO Dim sh, fso, ts, ver, p, resultPath, root, i, keyName, v, firstFree, cleanP, cleanV, rc, desc
>>"%VBS_FILE%" ECHO ver = WScript.Arguments(0)
>>"%VBS_FILE%" ECHO p = WScript.Arguments(1)
>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(2)
>>"%VBS_FILE%" ECHO desc = WScript.Arguments(3)
>>"%VBS_FILE%" ECHO If Right(p, 1) ^<^> "\" Then p = p ^& "\"
>>"%VBS_FILE%" ECHO cleanP = LCase(p)
>>"%VBS_FILE%" ECHO root = "HKCU\Software\Microsoft\Office\" ^& ver ^& "\Excel\Security\Trusted Locations\"
>>"%VBS_FILE%" ECHO firstFree = ""
>>"%VBS_FILE%" ECHO rc = 0
>>"%VBS_FILE%" ECHO Set sh = CreateObject("WScript.Shell")
>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS_FILE%" ECHO For i = 0 To 99
>>"%VBS_FILE%" ECHO   keyName = "Location" ^& CStr(i)
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   On Error Resume Next
>>"%VBS_FILE%" ECHO   v = sh.RegRead(root ^& keyName ^& "\Path")
>>"%VBS_FILE%" ECHO   If Err.Number ^<^> 0 Then
>>"%VBS_FILE%" ECHO     If firstFree = "" Then firstFree = keyName
>>"%VBS_FILE%" ECHO     Err.Clear
>>"%VBS_FILE%" ECHO   Else
>>"%VBS_FILE%" ECHO     cleanV = CStr(v)
>>"%VBS_FILE%" ECHO     If Right(cleanV, 1) ^<^> "\" Then cleanV = cleanV ^& "\"
>>"%VBS_FILE%" ECHO     If LCase(cleanV) = cleanP Then
>>"%VBS_FILE%" ECHO       Err.Clear
>>"%VBS_FILE%" ECHO       sh.RegWrite root ^& keyName ^& "\Description", desc, "REG_SZ"
>>"%VBS_FILE%" ECHO       sh.RegWrite root ^& keyName ^& "\AllowSubFolders", 0, "REG_DWORD"
>>"%VBS_FILE%" ECHO       Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO       ts.WriteLine "OK;EXISTS;" ^& keyName
>>"%VBS_FILE%" ECHO       ts.Close
>>"%VBS_FILE%" ECHO       WScript.Quit 0
>>"%VBS_FILE%" ECHO     End If
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO   On Error GoTo 0
>>"%VBS_FILE%" ECHO Next
>>"%VBS_FILE%" ECHO If firstFree = "" Then
>>"%VBS_FILE%" ECHO   Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO   ts.WriteLine "ERROR;NO_FREE_LOCATION"
>>"%VBS_FILE%" ECHO   ts.Close
>>"%VBS_FILE%" ECHO   WScript.Quit 2
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO On Error Resume Next
>>"%VBS_FILE%" ECHO Err.Clear
>>"%VBS_FILE%" ECHO sh.RegWrite root ^& firstFree ^& "\Path", p, "REG_SZ"
>>"%VBS_FILE%" ECHO If Err.Number ^<^> 0 Then rc = 3
>>"%VBS_FILE%" ECHO If rc = 0 Then sh.RegWrite root ^& firstFree ^& "\Description", desc, "REG_SZ"
>>"%VBS_FILE%" ECHO If rc = 0 And Err.Number ^<^> 0 Then rc = 4
>>"%VBS_FILE%" ECHO If rc = 0 Then sh.RegWrite root ^& firstFree ^& "\AllowSubFolders", 0, "REG_DWORD"
>>"%VBS_FILE%" ECHO If rc = 0 And Err.Number ^<^> 0 Then rc = 5
>>"%VBS_FILE%" ECHO If rc = 0 Then
>>"%VBS_FILE%" ECHO   Err.Clear
>>"%VBS_FILE%" ECHO   v = sh.RegRead(root ^& firstFree ^& "\Path")
>>"%VBS_FILE%" ECHO   If Err.Number ^<^> 0 Then
>>"%VBS_FILE%" ECHO     rc = 6
>>"%VBS_FILE%" ECHO   Else
>>"%VBS_FILE%" ECHO     cleanV = CStr(v)
>>"%VBS_FILE%" ECHO     If Right(cleanV, 1) ^<^> "\" Then cleanV = cleanV ^& "\"
>>"%VBS_FILE%" ECHO     If LCase(cleanV) ^<^> cleanP Then rc = 7
>>"%VBS_FILE%" ECHO   End If
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO On Error GoTo 0
>>"%VBS_FILE%" ECHO Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO If rc = 0 Then
>>"%VBS_FILE%" ECHO   ts.WriteLine "OK;ADDED;" ^& firstFree
>>"%VBS_FILE%" ECHO Else
>>"%VBS_FILE%" ECHO   ts.WriteLine "ERROR;WRITE_VERIFY;" ^& CStr(rc)
>>"%VBS_FILE%" ECHO End If
>>"%VBS_FILE%" ECHO ts.Close
>>"%VBS_FILE%" ECHO Set ts = Nothing
>>"%VBS_FILE%" ECHO Set fso = Nothing
>>"%VBS_FILE%" ECHO Set sh = Nothing
>>"%VBS_FILE%" ECHO WScript.Quit rc

CSCRIPT //NoLogo "%VBS_FILE%" "%EXCEL_VERSION%" "%DEST_DIR%" "%ADDIN_RESULT%" "%TRUST_DESCRIPTION%" >"%VBS_LOG%" 2>&1
SET "TRUST_RC=%ERRORLEVEL%"
IF EXIST "%VBS_LOG%" (
    FOR /F "usebackq delims=" %%L IN ("%VBS_LOG%") DO CALL :LOG "[TRUST VBS] %%L"
)
IF NOT EXIST "%ADDIN_RESULT%" (
    ECHO [ERROR] �H����m�B�z�����͵��G�ɡCExitCode=%TRUST_RC%
    CALL :LOG "[ERROR] Trusted Location helper produced no result file. ExitCode=%TRUST_RC%"
    EXIT /B 1
)

SET "TRUST_LINE="
SET /P TRUST_LINE=<"%ADDIN_RESULT%"
CALL :LOG "[TRUSTED LOCATION] %TRUST_LINE%"
FOR /F "tokens=1-3 delims=;" %%A IN ("%TRUST_LINE%") DO (
    IF /I "%%A"=="OK" (
        SET "TRUST_OK=1"
        SET "TRUST_ACTION=%%B"
        SET "TRUST_LOCATION_NAME=%%C"
    )
)
IF NOT "%TRUST_RC%"=="0" CALL :LOG "[INFO] Trusted Location helper ExitCode=%TRUST_RC%"
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
IF "%TRUST_OK%"=="1" EXIT /B 0
ECHO [ERROR] �L�k�إߩ����� Excel �H����m�C
CALL :LOG "[ERROR] Excel Trusted Location creation or verification failed."
EXIT /B 1


REM ===============================================================================
REM CREATE_LOGGER
REM �إ߯� ASCII VBS Logger�F�z�L ADODB.Stream �g�X UTF-8 �L BOM �E�_���i
REM Text Stream �O�� adTypeText�A�t�� Binary Stream �������L BOM �᪺���e
REM ===============================================================================
:CREATE_LOGGER
DEL /Q "%LOG_VBS%" 2>NUL
>"%LOG_VBS%" ECHO Option Explicit
>>"%LOG_VBS%" ECHO Const adTypeBinary = 1
>>"%LOG_VBS%" ECHO Const adTypeText = 2
>>"%LOG_VBS%" ECHO Const adSaveCreateOver = 2
>>"%LOG_VBS%" ECHO Dim p, s, txt, outStm, fso
>>"%LOG_VBS%" ECHO p = WScript.Arguments(0)
>>"%LOG_VBS%" ECHO s = WScript.Arguments(1) ^& vbCrLf
>>"%LOG_VBS%" ECHO Set txt = CreateObject("ADODB.Stream")
>>"%LOG_VBS%" ECHO txt.Type = adTypeText
>>"%LOG_VBS%" ECHO txt.Charset = "utf-8"
>>"%LOG_VBS%" ECHO txt.Open
>>"%LOG_VBS%" ECHO txt.WriteText s
>>"%LOG_VBS%" ECHO txt.Position = 3
>>"%LOG_VBS%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%LOG_VBS%" ECHO Set outStm = CreateObject("ADODB.Stream")
>>"%LOG_VBS%" ECHO outStm.Type = adTypeBinary
>>"%LOG_VBS%" ECHO outStm.Open
>>"%LOG_VBS%" ECHO If fso.FileExists(p) Then outStm.LoadFromFile p
>>"%LOG_VBS%" ECHO outStm.Position = outStm.Size
>>"%LOG_VBS%" ECHO txt.CopyTo outStm
>>"%LOG_VBS%" ECHO outStm.SaveToFile p, adSaveCreateOver
>>"%LOG_VBS%" ECHO outStm.Close
>>"%LOG_VBS%" ECHO txt.Close
>>"%LOG_VBS%" ECHO Set outStm = Nothing
>>"%LOG_VBS%" ECHO Set fso = Nothing
>>"%LOG_VBS%" ECHO Set txt = Nothing
SET "LOG_TEST=%TEMP%\ExcelAddinLogTest_%RANDOM%_%RANDOM%.txt"
SET "LOG_ERR=%TEMP%\ExcelAddinLogTest_%RANDOM%_%RANDOM%.err"
CSCRIPT //NoLogo "%LOG_VBS%" "%LOG_TEST%" "Logger���աGD:\VBA\CJPsAddin.xla" >"%LOG_ERR%" 2>&1
IF ERRORLEVEL 1 (
    TYPE "%LOG_ERR%"
    EXIT /B 1
)
IF NOT EXIST "%LOG_TEST%" EXIT /B 1
FOR %%A IN ("%LOG_TEST%") DO IF %%~zA LEQ 0 EXIT /B 1
DEL /Q "%LOG_TEST%" "%LOG_ERR%" 2>NUL
SET "LOG_TEST="
SET "LOG_ERR="
EXIT /B 0


REM ===============================================================================
REM LOG
REM �N�@���T�H UTF-8 �L BOM �g�J�E�_���i�F���ѮɥߧY����A�קK�R�q����
REM ===============================================================================
:LOG
SET "LOG_ERR=%TEMP%\ExcelAddinLog_%RANDOM%_%RANDOM%.err"
CSCRIPT //NoLogo "%LOG_VBS%" "%DIAG_FILE%" "%~1" >"%LOG_ERR%" 2>&1
IF ERRORLEVEL 1 GOTO :LOG_WRITE_ERROR
IF NOT EXIST "%DIAG_FILE%" GOTO :LOG_WRITE_ERROR
DEL /Q "%LOG_ERR%" 2>NUL
SET "LOG_ERR="
EXIT /B 0

:LOG_WRITE_ERROR
ECHO.
ECHO [ERROR] Diagnostic log write failed.
IF EXIST "%LOG_ERR%" TYPE "%LOG_ERR%"
ECHO.
ECHO Installer will stop so the installation failure is not hidden.
DEL /Q "%LOG_ERR%" 2>NUL
SET "LOG_ERR="
GOTO :ERROR_NO_LOG


REM ===============================================================================
REM CHECK_EXCEL_COM
REM �� ASCII VBS�G�إ� Excel COM�B���o Version�A�̫�@�w���� Quit
REM ===============================================================================
:CHECK_EXCEL_COM
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
>"%VBS_FILE%" ECHO Option Explicit
>>"%VBS_FILE%" ECHO Dim xl, fso, ts, resultPath, v, rc
>>"%VBS_FILE%" ECHO resultPath = WScript.Arguments(0)
>>"%VBS_FILE%" ECHO rc = 0
>>"%VBS_FILE%" ECHO On Error Resume Next
>>"%VBS_FILE%" ECHO Set xl = CreateObject("Excel.Application")
>>"%VBS_FILE%" ECHO If Err.Number ^<^> 0 Then rc = 1
>>"%VBS_FILE%" ECHO If rc = 0 Then v = xl.Version
>>"%VBS_FILE%" ECHO If rc = 0 And Len(v) = 0 Then rc = 2
>>"%VBS_FILE%" ECHO Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS_FILE%" ECHO Set ts = fso.CreateTextFile(resultPath, True, False)
>>"%VBS_FILE%" ECHO If rc = 0 Then ts.WriteLine v Else ts.WriteLine "ERROR"
>>"%VBS_FILE%" ECHO ts.Close
>>"%VBS_FILE%" ECHO If Not xl Is Nothing Then xl.Quit
>>"%VBS_FILE%" ECHO Set ts = Nothing
>>"%VBS_FILE%" ECHO Set fso = Nothing
>>"%VBS_FILE%" ECHO Set xl = Nothing
>>"%VBS_FILE%" ECHO WScript.Quit rc

CSCRIPT //NoLogo "%VBS_FILE%" "%ADDIN_RESULT%" >"%VBS_LOG%" 2>&1
SET "EXCEL_COM_RC=%ERRORLEVEL%"
IF NOT "%EXCEL_COM_RC%"=="0" (
    ECHO [ERROR] Excel COM check failed. ExitCode=%EXCEL_COM_RC%
    CALL :LOG "[ERROR] Excel COM check failed. ExitCode=%EXCEL_COM_RC%"
    EXIT /B 1
)
IF NOT EXIST "%ADDIN_RESULT%" (
    ECHO [ERROR] Excel COM check produced no result file.
    CALL :LOG "[ERROR] Excel COM check produced no result file."
    EXIT /B 1
)
SET /P EXCEL_VERSION=<"%ADDIN_RESULT%"
IF NOT DEFINED EXCEL_VERSION (
    ECHO [ERROR] Excel Version is empty.
    CALL :LOG "[ERROR] Excel Version is empty."
    EXIT /B 1
)
IF /I "%EXCEL_VERSION%"=="ERROR" (
    ECHO [ERROR] Excel COM could not return Version.
    CALL :LOG "[ERROR] Excel COM returned ERROR."
    EXIT /B 1
)
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" 2>NUL
EXIT /B 0


REM ===============================================================================
REM CHECK_MOTW
REM �����@���ɮ׸��|�F���� DIR /R �T�{ Zone.Identifier ADS�A�AŪ�� ZoneId�C
REM �u�� ZoneId=3�]Internet�^�� 4�]Restricted Sites�^�~�ݭn�Ѱ�����C
REM ===============================================================================
:CHECK_MOTW
SET "CHECK_FILE=%~1"
SET "MOTW_FOUND=0"
SET "ZONE_ID="
DIR /R "%CHECK_FILE%" 2>NUL | FINDSTR /I /C:":Zone.Identifier:$DATA" >NUL
IF ERRORLEVEL 1 GOTO :MOTW_NONE

SET "MOTW_FOUND=1"
FOR /F "tokens=2 delims==" %%Z IN ('MORE ^< "%CHECK_FILE%:Zone.Identifier" 2^>NUL ^| FINDSTR /I /B /C:"ZoneId="') DO SET "ZONE_ID=%%Z"
ECHO [INFO] Zone.Identifier found: %CHECK_FILE%
CALL :LOG "[INFO] Zone.Identifier : Found - %CHECK_FILE%"
IF NOT DEFINED ZONE_ID GOTO :MOTW_ZONE_UNKNOWN

ECHO [INFO] ZoneId=%ZONE_ID%
CALL :LOG "[INFO] ZoneId          : %ZONE_ID%"
IF "%ZONE_ID%"=="3" GOTO :MOTW_REMOVE
IF "%ZONE_ID%"=="4" GOTO :MOTW_REMOVE

ECHO [OK] Zone.Identifier exists, but ZoneId=%ZONE_ID% does not require unblocking.
CALL :LOG "[OK] Zone.Identifier exists but does not require Internet/Restricted unblocking."
SET "CHECK_FILE="
EXIT /B 0

:MOTW_ZONE_UNKNOWN
ECHO [INFO] Zone.Identifier exists, but ZoneId was not readable; leaving it unchanged.
CALL :LOG "[INFO] ZoneId          : Not found"
CALL :LOG "[INFO] Zone.Identifier was left unchanged."
SET "CHECK_FILE="
EXIT /B 0

:MOTW_REMOVE
ECHO [!] ZoneId=%ZONE_ID%; attempting to remove MOTW...
CALL :LOG "[ACTION] Removing MOTW because ZoneId=%ZONE_ID%."
WHERE POWERSHELL.EXE >NUL 2>&1
IF ERRORLEVEL 1 GOTO :MOTW_DEL_STREAM
POWERSHELL.EXE -NoProfile -NonInteractive -Command "Unblock-File -LiteralPath $env:CHECK_FILE -ErrorAction Stop" >NUL 2>&1

DIR /R "%CHECK_FILE%" 2>NUL | FINDSTR /I /C:":Zone.Identifier:$DATA" >NUL
IF ERRORLEVEL 1 GOTO :MOTW_REMOVED

:MOTW_DEL_STREAM
DEL "%CHECK_FILE%:Zone.Identifier" >NUL 2>&1
DIR /R "%CHECK_FILE%" 2>NUL | FINDSTR /I /C:":Zone.Identifier:$DATA" >NUL
IF ERRORLEVEL 1 GOTO :MOTW_REMOVED

ECHO [WARNING] Zone.Identifier still exists. Windows or enterprise policy may prevent removal.
CALL :LOG "[WARNING] MOTW could not be removed: %CHECK_FILE%"
SET "CHECK_FILE="
EXIT /B 0

:MOTW_REMOVED
ECHO [OK] MOTW removed; Zone.Identifier no longer exists.
CALL :LOG "[OK] MOTW removed and Zone.Identifier no longer exists: %CHECK_FILE%"
SET "CHECK_FILE="
EXIT /B 0

:MOTW_NONE
ECHO [OK] ���o�{ Zone.Identifier�A���ݭn�B�z MOTW�G%CHECK_FILE%
CALL :LOG "[INFO] Zone.Identifier : Not found - %CHECK_FILE%"
CALL :LOG "[OK] MOTW handling not required."
SET "CHECK_FILE="
EXIT /B 0

REM ===============================================================================
REM CHECK_POLICY
REM �ȰO����쪺 Policy Key�F�� Policy ���N�����W�q���@�w�Q����
REM ===============================================================================
:CHECK_POLICY
REG QUERY "%~1" >NUL 2>&1
IF ERRORLEVEL 1 EXIT /B 0
SET "POLICY_FOUND=1"
CALL :LOG "[POLICY] %~1"
EXIT /B 0


REM ===============================================================================
REM CLEAN_TEMP
REM �M����������إߪ��Ȧs VBS / Result / Log
REM ===============================================================================
:CLEAN_TEMP
DEL /Q "%VBS_FILE%" "%ADDIN_RESULT%" "%VBS_LOG%" "%LOG_VBS%" 2>NUL
EXIT /B 0
